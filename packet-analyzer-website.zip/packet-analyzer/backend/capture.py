"""Live packet capture (Scapy AsyncSniffer) used while an automation task runs.
Needs Npcap on Windows and an Administrator terminal. Captures the whole adapter."""
import threading, time, collections


class LiveCapture:
    def __init__(self, path):
        self.path, self.lock = path, threading.Lock()
        self.rows, self.by_proto = [], collections.Counter()
        self.total = self.bytes = 0
        self.t0 = None
        self.ips = set()          # remote IPs the automated browser really talked to (from CDP)
        self.sniffer = self.writer = None

    def start(self):
        """Returns None on success, or an error string."""
        try:
            from scapy.all import AsyncSniffer, PcapWriter, IP, IPv6, TCP, UDP
            from main import classify
            self.writer = PcapWriter(self.path, append=False, sync=True)

            def cb(p):
                try:
                    t = float(p.time)
                    if self.t0 is None: self.t0 = t
                    ip = p[IP] if p.haslayer(IP) else p[IPv6] if p.haslayer(IPv6) else None
                    sp = dp = None
                    if p.haslayer(TCP): sp, dp = p[TCP].sport, p[TCP].dport
                    elif p.haslayer(UDP): sp, dp = p[UDP].sport, p[UDP].dport
                    proto = classify(p)
                    row = {"t": round(t - self.t0, 3), "src": ip.src if ip else "", "dst": ip.dst if ip else "",
                           "proto": proto, "sport": sp, "dport": dp, "len": len(p), "info": p.summary()[:110]}
                    self.writer.write(p)
                    with self.lock:
                        self.rows.append(row); self.total += 1; self.bytes += len(p); self.by_proto[proto] += 1
                except Exception:
                    pass

            self.sniffer = AsyncSniffer(prn=cb, store=False)
            self.sniffer.start()
            time.sleep(1.0)
            err = getattr(self.sniffer, "exception", None)
            if err or not self.sniffer.running:
                raise RuntimeError(err or "sniffer did not start")
            return None
        except Exception as e:
            return f"Packet capture unavailable ({str(e)[:150]}). Install Npcap (npcap.com) and run the backend terminal as Administrator."

    def drain(self):
        with self.lock:
            rows, self.rows = self.rows, []
            stats = {"total": self.total, "bytes": self.bytes, "protocols": dict(self.by_proto)}
        for r in rows:
            r["browser"] = r["src"] in self.ips or r["dst"] in self.ips
        return rows, stats

    def stop(self):
        try:
            if self.sniffer and self.sniffer.running: self.sniffer.stop()
        except Exception:
            pass
        try:
            if self.writer: self.writer.close()
        except Exception:
            pass
