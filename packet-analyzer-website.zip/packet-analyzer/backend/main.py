"""Packet analysis API. Only parses real uploaded captures; nothing is fabricated."""
import os, uuid, ipaddress, tempfile, collections
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from scapy.all import PcapReader, IP, IPv6, TCP, UDP, ICMP, DNS

load_dotenv()
from automation import router as automation_router
app = FastAPI(title="Packet Analyzer")
app.include_router(automation_router)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"],
                   allow_methods=["*"], allow_headers=["*"])

CAPTURES: dict[str, dict] = {}
MAX_BYTES = 200 * 1024 * 1024
MAX_ROWS = 300_000
MAGICS = {bytes.fromhex(h) for h in
          ("0a0d0d0a", "a1b2c3d4", "d4c3b2a1", "a1b23c4d", "4d3cb2a1")}


def classify(p):
    if p.haslayer(DNS): return "DNS"
    if p.haslayer(TCP):
        ports = {p[TCP].sport, p[TCP].dport}
        if 443 in ports: return "TLS"      # port-based guess; contents are encrypted
        if ports & {80, 8080}: return "HTTP"
        return "TCP"
    if p.haslayer(UDP): return "UDP"
    if p.haslayer(ICMP): return "ICMP"
    return "Other"


def analyze(path: str, name: str) -> dict:
    rows, dns_names = [], {}
    syn_ports = collections.defaultdict(set)
    long_dns = collections.Counter()
    total = total_bytes = 0
    t0 = None
    with PcapReader(path) as reader:
        for p in reader:
            total += 1
            ln = len(p); total_bytes += ln
            t = float(p.time); t0 = t if t0 is None else t0
            ip = p[IP] if p.haslayer(IP) else p[IPv6] if p.haslayer(IPv6) else None
            src, dst = (ip.src, ip.dst) if ip else ("", "")
            proto = classify(p)
            sport = dport = None
            if p.haslayer(TCP): sport, dport = p[TCP].sport, p[TCP].dport
            elif p.haslayer(UDP): sport, dport = p[UDP].sport, p[UDP].dport
            if p.haslayer(TCP) and ip and int(p[TCP].flags) & 0x12 == 0x02:
                syn_ports[(src, dst)].add(dport)
            if p.haslayer(DNS):
                d = p[DNS]
                try:
                    if d.qr == 0 and d.qd is not None:
                        q = d.qd.qname.decode(errors="ignore").rstrip(".")
                        if len(q) > 50: long_dns[(src, q[:60])] += 1
                    for i in range(d.ancount or 0):
                        rr = d.an[i]
                        if rr.type in (1, 28):
                            dns_names[str(rr.rdata)] = rr.rrname.decode(errors="ignore").rstrip(".")
                except Exception:
                    pass
            if len(rows) < MAX_ROWS:
                rows.append({"n": total, "t": t - t0, "src": src, "dst": dst, "proto": proto,
                             "sport": sport, "dport": dport, "len": ln, "info": p.summary()[:160]})
    if not total:
        raise ValueError("Capture contains no packets")

    by_proto = collections.defaultdict(lambda: {"packets": 0, "bytes": 0})
    series = collections.defaultdict(lambda: [0, 0])
    hosts, endpoints = collections.Counter(), collections.defaultdict(int)
    for r in rows:
        bp = by_proto[r["proto"]]; bp["packets"] += 1; bp["bytes"] += r["len"]
        s = series[int(r["t"])]; s[0] += 1; s[1] += r["len"]
        for ipa in (r["src"], r["dst"]):
            if not ipa: continue
            endpoints[ipa] += r["len"]
            try:
                if ipaddress.ip_address(ipa).is_global: hosts[ipa] += 1
            except ValueError:
                pass
    suspicious = []
    for (s, d), ports in syn_ports.items():
        if len(ports) >= 20:
            suspicious.append({"rule": "Possible port scan",
                               "detail": f"{s} sent SYNs to {len(ports)} distinct ports on {d}"})
    for (s, q), c in long_dns.items():
        suspicious.append({"rule": "Unusually long DNS name",
                           "detail": f"{s} queried a {len(q)}+ char name ({q}...) {c}x"})
    return {
        "name": name, "total_packets": total, "total_bytes": total_bytes,
        "rows_kept": len(rows), "truncated": total > len(rows),
        "protocols": [{"protocol": k, **v} for k, v in
                      sorted(by_proto.items(), key=lambda kv: -kv[1]["packets"])],
        "timeline": [{"t": k, "packets": v[0], "bytes": v[1]} for k, v in sorted(series.items())],
        # No reliable local/remote perspective in a raw capture, so no in/out split is reported.
        "hosts": [{"host": dns_names.get(h, h), "ip": h, "named_via_dns": h in dns_names, "packets": c}
                  for h, c in hosts.most_common(8)],
        "top_endpoints": [{"ip": k, "bytes": v} for k, v in
                          sorted(endpoints.items(), key=lambda kv: -kv[1])[:10]],
        "suspicious": suspicious, "_rows": rows,
    }


def public(c): return {k: v for k, v in c.items() if k != "_rows"}


@app.post("/api/captures")
async def upload(file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".pcap", ".pcapng")):
        raise HTTPException(400, "Only .pcap and .pcapng files are supported")
    data = await file.read()
    if len(data) > MAX_BYTES: raise HTTPException(413, "File exceeds 200 MB limit")
    if data[:4] not in MAGICS: raise HTTPException(400, "Not a valid pcap/pcapng file (bad header)")
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(data)
    try:
        result = analyze(tmp.name, file.filename)
    except Exception as e:
        raise HTTPException(422, f"Failed to parse capture: {e}")
    finally:
        os.unlink(tmp.name)
    cid = uuid.uuid4().hex[:8]
    CAPTURES[cid] = result
    return {"id": cid, **public(result)}


@app.get("/api/captures")
def list_captures():
    return [{"id": k, "name": v["name"], "total_packets": v["total_packets"]} for k, v in CAPTURES.items()]


def get_cap(cid):
    if cid not in CAPTURES: raise HTTPException(404, "Capture not found")
    return CAPTURES[cid]


@app.get("/api/captures/{cid}/summary")
def summary(cid: str): return {"id": cid, **public(get_cap(cid))}


@app.get("/api/captures/{cid}/packets")
def packets(cid: str, q: str = "", proto: str = "", src: str = "", dst: str = "",
            port: int | None = None, t_min: float | None = None, t_max: float | None = None,
            limit: int = 200, offset: int = 0):
    out = []
    for r in get_cap(cid)["_rows"]:
        if proto and r["proto"] != proto: continue
        if src and r["src"] != src: continue
        if dst and r["dst"] != dst: continue
        if port is not None and port not in (r["sport"], r["dport"]): continue
        if t_min is not None and r["t"] < t_min: continue
        if t_max is not None and r["t"] > t_max: continue
        if q and q.lower() not in f'{r["src"]} {r["dst"]} {r["proto"]} {r["info"]}'.lower(): continue
        out.append(r)
    return {"total": len(out), "packets": out[offset:offset + min(limit, 1000)]}


class Chat(BaseModel):
    question: str


@app.post("/api/captures/{cid}/chat")
async def chat(cid: str, body: Chat):
    key = os.getenv("GROQ_API_KEY")
    if not key: raise HTTPException(503, "GROQ_API_KEY is not configured on the server")
    s = public(get_cap(cid))
    system = ("You analyze network captures. Use ONLY the extracted statistics below. "
              "Label statements as 'Observed' (directly in the data) or 'Possible interpretation'. "
              "TLS traffic is encrypted; never claim its contents are readable. "
              "Protocol labels are port-based heuristics. If the data can't answer, say so.\n\n"
              f"CAPTURE STATS (JSON): {s}")
    async with httpx.AsyncClient(timeout=60) as cl:
        r = await cl.post("https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json={"model": os.getenv("GROQ_MODEL", "openai/gpt-oss-120b"), "temperature": 0.2,
                  "messages": [{"role": "system", "content": system},
                               {"role": "user", "content": body.question}]})
    if r.status_code != 200: raise HTTPException(502, f"Groq error {r.status_code}: {r.text[:200]}")
    return {"answer": r.json()["choices"][0]["message"]["content"]}
