"""AI website automation: Groq plans -> validated steps -> Playwright executes, events over WebSocket.
Runs Playwright's sync API in a worker thread (works on Windows with uvicorn --reload)."""
import os, json, asyncio, threading, base64, time, uuid
from urllib.parse import quote_plus, urlparse
import httpx
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()
ALLOWED = set(os.getenv("ALLOWED_SITES", "youtube.com,github.com,google.com,wikipedia.org,linkedin.com").split(","))
SEARCH = {"youtube": "https://www.youtube.com/results?search_query=", "github": "https://github.com/search?q=",
          "google": "https://www.google.com/search?q=", "wikipedia": "https://en.wikipedia.org/w/index.php?search=",
          "linkedin": "https://www.linkedin.com/search/results/all/?keywords="}


def host_ok(url):
    u = urlparse(url); h = u.hostname or ""
    return u.scheme in ("http", "https") and any(h == d or h.endswith("." + d) for d in ALLOWED)


def describe(s):
    a = s["action"]
    return {"goto": f"Open {s.get('url')}", "search": f"Search {s.get('site')} for \"{s.get('query')}\"",
            "scroll": f"Scroll down {s.get('amount', 600)}px", "click_text": f"Click element with text \"{s.get('text')}\"",
            "wait": f"Wait {s.get('seconds', 1)}s"}[a]


async def plan(prompt):
    key = os.getenv("GROQ_API_KEY")
    if not key: raise RuntimeError("GROQ_API_KEY is not configured on the server")
    system = ("Convert the user's request into browser steps. Reply with JSON only: {\"steps\":[...]}. Allowed steps: "
              '{"action":"goto","url":"https://..."}, {"action":"search","site":"youtube|github|google|wikipedia|linkedin","query":"..."}, '
              '{"action":"scroll","amount":600}, {"action":"click_text","text":"..."}, {"action":"wait","seconds":2}. '
              "Max 12 steps. Never log in, type credentials, buy, post or submit forms.")
    async with httpx.AsyncClient(timeout=60) as cl:
        r = await cl.post("https://api.groq.com/openai/v1/chat/completions", headers={"Authorization": f"Bearer {key}"},
            json={"model": os.getenv("GROQ_MODEL", "openai/gpt-oss-120b"), "temperature": 0,
                  "response_format": {"type": "json_object"},
                  "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]})
    if r.status_code != 200: raise RuntimeError(f"Groq error {r.status_code}: {r.text[:200]}")
    raw = json.loads(r.json()["choices"][0]["message"]["content"]).get("steps", [])[:12]
    steps, blocked = [], []
    for s in raw:
        try:
            a = s["action"]
            if a == "goto" and not host_ok(s["url"]): blocked.append(f"Blocked (site not allowed): {s['url']}"); continue
            if a == "search" and (s["site"] not in SEARCH or not str(s["query"]).strip()): blocked.append(f"Blocked search: {s}"); continue
            if a not in ("goto", "search", "scroll", "click_text", "wait"): blocked.append(f"Blocked action: {a}"); continue
            if a == "click_text" and not str(s.get("text", "")).strip(): continue
            steps.append(s); describe(s)
        except Exception:
            blocked.append(f"Invalid step ignored: {s}")
    return steps, blocked


class Ctl:
    def __init__(self):
        self.stop, self.resume, self.confirm = threading.Event(), threading.Event(), threading.Event()
        self.resume.set(); self.approved = False


def run_steps(steps, emit, ctl, cap=None):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        emit({"type": "error", "message": "Playwright missing. Run: pip install playwright && playwright install chromium"}); return
    done = failed = skipped = 0
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            page = browser.new_page(viewport={"width": 1280, "height": 720})
            try:  # browser-level network events straight from Chrome (real remote IP, protocol, TLS, size)
                cdp = page.context.new_cdp_session(page); cdp.send("Network.enable")
                def on_resp(e):
                    r = e["response"]; ip = (r.get("remoteIPAddress") or "").strip("[]")
                    if ip and cap: cap.ips.add(ip)
                    emit({"type": "net", "id": e["requestId"], "status": r.get("status"), "url": r.get("url", "")[:140],
                          "mime": r.get("mimeType", ""), "ip": ip, "port": r.get("remotePort"), "proto": r.get("protocol", ""),
                          "tls": (r.get("securityDetails") or {}).get("protocol", ""), "rtype": e.get("type", "")})
                def on_fin(e):
                    emit({"type": "net_size", "id": e["requestId"], "bytes": int(e.get("encodedDataLength", 0))})
                cdp.on("Network.responseReceived", on_resp); cdp.on("Network.loadingFinished", on_fin)
            except Exception:
                pass
            emit({"type": "status", "state": "running"})
            for i, s in enumerate(steps):
                ctl.resume.wait()
                if ctl.stop.is_set(): break
                emit({"type": "step", "index": i, "status": "running"})
                try:
                    a = s["action"]
                    if a == "click_text":
                        ctl.confirm.clear(); ctl.approved = False
                        emit({"type": "confirm", "index": i, "text": describe(s)})
                        ctl.confirm.wait(timeout=120)
                        if not ctl.approved:
                            skipped += 1; emit({"type": "step", "index": i, "status": "skipped"}); continue
                        page.get_by_text(s["text"]).first.click(timeout=8000)
                    elif a == "goto": page.goto(s["url"], timeout=30000)
                    elif a == "search": page.goto(SEARCH[s["site"]] + quote_plus(str(s["query"])), timeout=30000)
                    elif a == "scroll": page.mouse.wheel(0, int(s.get("amount", 600)))
                    elif a == "wait": page.wait_for_timeout(min(float(s.get("seconds", 1)), 5) * 1000)
                    page.wait_for_timeout(800)
                    shot = base64.b64encode(page.screenshot(type="jpeg", quality=50)).decode()
                    emit({"type": "shot", "data": shot, "url": page.url, "title": page.title()})
                    done += 1; emit({"type": "step", "index": i, "status": "done"})
                except Exception as e:
                    failed += 1; emit({"type": "step", "index": i, "status": "error", "detail": str(e)[:200]}); break
            page.wait_for_timeout(1500); browser.close()
    except Exception as e:
        emit({"type": "error", "message": f"Browser error: {str(e)[:300]}"}); return
    state = "stopped" if ctl.stop.is_set() else "failed" if failed else "completed"
    emit({"type": "done", "state": state, "summary": f"{done} of {len(steps)} steps completed, {failed} failed, {skipped} skipped."})


CAP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "captures")
os.makedirs(CAP_DIR, exist_ok=True)


async def safe(ws, msg):
    try: await ws.send_json(msg)
    except Exception: pass


async def session(ws, steps, emit, ctl, capture_on):
    cap = None
    if capture_on:
        from capture import LiveCapture
        cap = LiveCapture(os.path.join(CAP_DIR, f"automation_{int(time.time())}.pcap"))
        err = await asyncio.to_thread(cap.start)
        if err: await safe(ws, {"type": "capture_status", "state": "unavailable", "message": err}); cap = None
        else: await safe(ws, {"type": "capture_status", "state": "capturing"})

    async def flusher():
        while cap:
            await asyncio.sleep(0.4)
            rows, stats = cap.drain()
            if rows: await safe(ws, {"type": "packets", "rows": rows[-200:], "stats": stats})
    ft = asyncio.create_task(flusher())
    try:
        await asyncio.to_thread(run_steps, steps, emit, ctl, cap)
    finally:
        ft.cancel()
        if cap:
            await asyncio.sleep(1.0)
            await asyncio.to_thread(cap.stop)
            rows, stats = cap.drain()
            if rows: await safe(ws, {"type": "packets", "rows": rows[-200:], "stats": stats})
            try:
                from main import analyze, CAPTURES, public
                result = await asyncio.to_thread(analyze, cap.path, os.path.basename(cap.path))
                cid = uuid.uuid4().hex[:8]; CAPTURES[cid] = result
                await safe(ws, {"type": "capture_ready", "capture": {"id": cid, **public(result)}, "path": cap.path})
            except Exception as e:
                await safe(ws, {"type": "capture_status", "state": "failed", "message": f"Could not analyze capture: {str(e)[:150]}"})


@router.websocket("/ws/automation")
async def ws_auto(ws: WebSocket):
    await ws.accept()
    loop = asyncio.get_running_loop(); ctl = None; task = None
    emit = lambda ev: asyncio.run_coroutine_threadsafe(ws.send_json(ev), loop)
    try:
        while True:
            m = await ws.receive_json(); t = m.get("type")
            if t == "run" and not (task and not task.done()):
                try: steps, blocked = await plan(str(m.get("prompt", ""))[:1000])
                except Exception as e: await ws.send_json({"type": "error", "message": str(e)}); continue
                await ws.send_json({"type": "plan", "steps": [describe(s) for s in steps], "blocked": blocked})
                if not steps: continue
                ctl = Ctl(); task = asyncio.create_task(session(ws, steps, emit, ctl, bool(m.get("capture", True))))
            elif ctl and t == "pause": ctl.resume.clear(); await ws.send_json({"type": "status", "state": "paused"})
            elif ctl and t == "resume": ctl.resume.set(); await ws.send_json({"type": "status", "state": "running"})
            elif ctl and t == "stop": ctl.stop.set(); ctl.resume.set(); ctl.confirm.set()
            elif ctl and t == "confirm": ctl.approved = bool(m.get("approve")); ctl.confirm.set()
    except WebSocketDisconnect:
        if ctl: ctl.stop.set(); ctl.resume.set(); ctl.confirm.set()
