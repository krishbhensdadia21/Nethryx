import { useState, useEffect } from 'react'
import { Network, Home as HomeIcon, FileSearch, Bot, Menu, X } from 'lucide-react'
import Home from './Home.jsx'
import PcapPage from './PcapPage.jsx'
import Automation from './Automation.jsx'

const ROUTES = [
  { path: '/', label: 'Home', icon: HomeIcon },
  { path: '/pcap', label: 'PCAP Uploader', icon: FileSearch },
  { path: '/automation', label: 'AI Automation', icon: Bot },
]
const read = () => { const p = window.location.hash.replace(/^#/, '') || '/'; return ROUTES.some(r => r.path === p) ? p : '/' }

export default function App() {
  const [route, setRoute] = useState(read)
  const [cap, setCap] = useState(null)      // shared so a capture from Automation opens in the PCAP dashboard
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const on = () => { setRoute(read()); window.scrollTo({ top: 0 }) }
    window.addEventListener('hashchange', on); return () => window.removeEventListener('hashchange', on)
  }, [])
  const go = p => { window.location.hash = p; setOpen(false) }

  return (
    <>
      <div className="bg-scene"><div className="orb a" /><div className="orb b" /><div className="orb c" /></div>

      <header className="sticky top-0 z-40 px-3 pt-3 sm:px-6 sm:pt-4">
        <div className="glass-strong mx-auto flex max-w-6xl items-center justify-between rounded-full px-4 py-2.5 sm:px-6">
          <button onClick={() => go('/')} className="flex items-center gap-2 font-bold text-white">
            <span className="grid h-9 w-9 place-items-center rounded-full btn-primary"><Network size={18} /></span>
            <span className="hidden sm:inline">Packet Analyzer</span>
          </button>
          <nav className="hidden items-center gap-1 md:flex">
            {ROUTES.map(r => (
              <button key={r.path} onClick={() => go(r.path)}
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm transition ${route === r.path ? 'bg-white/20 text-white shadow-inner' : 'text-slate-300 hover:bg-white/10 hover:text-white'}`}>
                <r.icon size={16} />{r.label}</button>))}
          </nav>
          <button className="rounded-full p-2 text-white md:hidden" onClick={() => setOpen(o => !o)} aria-label="Menu">{open ? <X size={22} /> : <Menu size={22} />}</button>
        </div>
        {open && (
          <div className="glass-strong mx-auto mt-2 flex max-w-6xl flex-col gap-1 rounded-3xl p-2 md:hidden">
            {ROUTES.map(r => (
              <button key={r.path} onClick={() => go(r.path)}
                className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm ${route === r.path ? 'bg-white/20 text-white' : 'text-slate-300'}`}><r.icon size={18} />{r.label}</button>))}
          </div>)}
      </header>

      <main className="mx-auto max-w-[1400px] px-4 pb-16 pt-8 sm:px-8">
        {route === '/' && <Home go={go} />}
        {route === '/pcap' && <PcapPage cap={cap} setCap={setCap} />}
        {/* kept mounted so a running task/WebSocket survives navigating between pages */}
        <div style={{ display: route === '/automation' ? 'block' : 'none' }}>
          <Automation onCapture={c => { setCap(c); go('/pcap') }} />
        </div>
      </main>

      <footer className="px-4 pb-8 text-center text-xs text-slate-500">Network Packet Analyzer · Real captures, honest analysis</footer>
    </>
  )
}
