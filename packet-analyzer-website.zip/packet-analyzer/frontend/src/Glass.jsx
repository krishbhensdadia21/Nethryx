export const Glass = ({ className = '', strong, hover, children, ...rest }) => (
  <div className={`rounded-3xl ${strong ? 'glass-strong' : 'glass'} ${hover ? 'glass-hover' : ''} ${className}`} {...rest}>{children}</div>
)
export const Panel = ({ className = '', title, right, children }) => (
  <Glass className={`p-6 ${className}`}>
    <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
      <h3 className="text-lg font-semibold text-white">{title}</h3>{right}
    </div>
    {children}
  </Glass>
)
export const PageHeader = ({ eyebrow, title, subtitle }) => (
  <div className="mb-8 fade-in">
    <div className="text-xs font-semibold uppercase tracking-[.2em] text-sky-300">{eyebrow}</div>
    <h1 className="mt-2 text-3xl font-extrabold text-white sm:text-4xl">{title}</h1>
    {subtitle && <p className="mt-2 max-w-2xl text-slate-300">{subtitle}</p>}
  </div>
)
