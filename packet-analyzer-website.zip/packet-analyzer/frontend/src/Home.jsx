import { FileSearch, Bot, ArrowRight, UploadCloud, Cpu, BarChart3, ShieldAlert, Sparkles, Radio, Globe, MonitorPlay, Save,
  Lock, Layers, Server, Database, Zap, ChevronRight } from 'lucide-react'
import { Glass } from './Glass.jsx'

const Section = ({ id, eyebrow, title, sub, children }) => (
  <section id={id} className="mt-24 scroll-mt-28">
    <div className="mb-10 text-center">
      <div className="text-xs font-semibold uppercase tracking-[.2em] text-sky-300">{eyebrow}</div>
      <h2 className="mt-2 text-3xl font-extrabold text-white sm:text-4xl">{title}</h2>
      {sub && <p className="mx-auto mt-3 max-w-2xl text-slate-300">{sub}</p>}
    </div>
    {children}
  </section>
)

function Flow({ steps }) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-none xl:[grid-template-columns:repeat(var(--n),minmax(0,1fr))]" style={{ '--n': steps.length }}>
      {steps.map((s, i) => (
        <Glass key={s.title} hover className="relative p-5">
          <div className="flex items-center justify-between">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10"><s.icon size={20} className="text-sky-300" /></span>
            <span className="text-3xl font-extrabold text-white/15">0{i + 1}</span>
          </div>
          <h4 className="mt-4 font-semibold text-white">{s.title}</h4>
          <p className="mt-1.5 text-sm leading-relaxed text-slate-300">{s.text}</p>
          {i < steps.length - 1 && <ChevronRight className="absolute -right-3.5 top-1/2 z-10 hidden -translate-y-1/2 text-sky-300/70 xl:block" size={26} />}
        </Glass>
      ))}
    </div>
  )
}

const PCAP_FLOW = [
  { icon: UploadCloud, title: 'Upload', text: 'Drop a .pcap or .pcapng file (up to 200 MB). The header is validated before anything is parsed.' },
  { icon: Cpu, title: 'Parse', text: 'Scapy reads every packet: protocols, ports, IPs, sizes, timestamps and DNS answers.' },
  { icon: ShieldAlert, title: 'Detect', text: 'Built-in rules flag possible port scans and unusually long DNS names. No guessing.' },
  { icon: BarChart3, title: 'Visualize', text: 'The dashboard shows protocol charts, traffic over time and top hosts from your real data.' },
]
const AI_FLOW = [
  { icon: Sparkles, title: 'Describe', text: 'Write a task in plain English, e.g. “Open YouTube and search for Python tutorials”.' },
  { icon: Cpu, title: 'AI Plans', text: 'The Groq LLM converts it into at most 12 simple steps. Anything off the allow-list is blocked.' },
  { icon: MonitorPlay, title: 'Execute', text: 'Playwright drives a real Chrome window. You can pause, resume or stop at any time.' },
  { icon: Radio, title: 'Capture', text: 'Scapy sniffs live packets while Chrome’s own network requests stream in beside them.' },
  { icon: Save, title: 'Analyze', text: 'The capture is saved and can be opened straight in the PCAP dashboard.' },
]
const FEATURES = [
  { icon: FileSearch, t: 'Real capture analysis', d: 'Nothing is fabricated. Every chart and number comes from the file you upload.' },
  { icon: Bot, t: 'AI browser automation', d: 'Natural-language tasks turned into validated, safe browser steps.' },
  { icon: Radio, t: 'Live packet transfer', d: 'Watch packets and browser requests arrive in real time during a task.' },
  { icon: ShieldAlert, t: 'Suspicious pattern rules', d: 'Port-scan and long-DNS heuristics, clearly labelled as rule-based.' },
  { icon: Lock, t: 'Safety first', d: 'Site allow-list, no logins, no purchases, no form submissions, and confirmation prompts.' },
  { icon: Layers, t: 'Honest about limits', d: 'HTTPS is encrypted and never shown as readable; protocol labels are port-based.' },
]
const STACK = [
  { icon: Layers, t: 'React + Vite', d: 'Frontend UI, Recharts, Tailwind' },
  { icon: Server, t: 'FastAPI', d: 'REST + WebSocket backend' },
  { icon: Database, t: 'Scapy', d: 'Packet parsing and live sniffing' },
  { icon: Globe, t: 'Playwright', d: 'Real Chrome automation' },
  { icon: Zap, t: 'Groq LLM', d: 'Plans browser steps' },
]

export default function Home({ go }) {
  return (
    <div className="fade-in">
      {/* hero */}
      <section className="pt-10 text-center sm:pt-20">
        <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-sky-200"><Sparkles size={14} />Packet analysis + AI browser automation</span>
        <h1 className="mx-auto mt-6 max-w-4xl text-4xl font-extrabold leading-tight text-white sm:text-6xl">
          See what your network is <span className="text-grad">really doing</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-300">
          Network Packet Analyzer turns raw packet captures into clear dashboards, and lets an AI drive a real browser while it records the traffic that task creates.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button onClick={() => go('/pcap')} className="btn-primary flex items-center gap-2 rounded-full px-7 py-3">Upload a PCAP <ArrowRight size={18} /></button>
          <button onClick={() => go('/automation')} className="btn-glass flex items-center gap-2 rounded-full px-7 py-3">Try AI Automation <Bot size={18} /></button>
        </div>
        <div className="mx-auto mt-14 grid max-w-3xl grid-cols-2 gap-4 sm:grid-cols-4">
          {[['2', 'Analysis modes'], ['.pcap / .pcapng', 'Supported files'], ['≤ 12', 'AI steps per task'], ['100%', 'Real data']].map(([a, b]) => (
            <Glass key={b} className="px-3 py-4"><div className="text-lg font-bold text-white sm:text-xl">{a}</div><div className="text-xs text-slate-400">{b}</div></Glass>))}
        </div>
      </section>

      {/* what is it */}
      <Section id="about" eyebrow="About" title="What is this website?"
        sub="A small toolkit for understanding network traffic, built around two tools that share one dashboard.">
        <div className="grid gap-5 md:grid-cols-2">
          <Glass strong hover className="p-8">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white/10"><FileSearch className="text-sky-300" size={26} /></span>
            <h3 className="mt-5 text-xl font-bold text-white">PCAP Uploader</h3>
            <p className="mt-2 text-slate-300">Already have a Wireshark or tcpdump capture? Upload it and instantly see total packets, data volume, protocol mix, traffic over time, the busiest hosts and any flagged patterns.</p>
            <button onClick={() => go('/pcap')} className="mt-5 flex items-center gap-1 font-medium text-sky-300 hover:gap-2 transition-all">Open dashboard <ArrowRight size={16} /></button>
          </Glass>
          <Glass strong hover className="p-8">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white/10"><Bot className="text-violet-300" size={26} /></span>
            <h3 className="mt-5 text-xl font-bold text-white">AI Automation</h3>
            <p className="mt-2 text-slate-300">Type what you want a browser to do. The AI plans safe steps, Chrome performs them on screen, and live packets plus browser requests are shown while it happens.</p>
            <button onClick={() => go('/automation')} className="mt-5 flex items-center gap-1 font-medium text-violet-300 hover:gap-2 transition-all">Open dashboard <ArrowRight size={16} /></button>
          </Glass>
        </div>
      </Section>

      {/* features */}
      <Section id="features" eyebrow="Features" title="Built to be accurate, not flashy">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(f => (
            <Glass key={f.t} hover className="p-6">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10"><f.icon size={20} className="text-sky-300" /></span>
              <h4 className="mt-4 font-semibold text-white">{f.t}</h4>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-300">{f.d}</p>
            </Glass>))}
        </div>
      </Section>

      {/* workflows */}
      <Section id="workflow" eyebrow="Workflow" title="How the PCAP Uploader works" sub="From raw file to dashboard in four steps.">
        <Flow steps={PCAP_FLOW} />
      </Section>
      <section className="mt-20">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">How AI Automation works</h2>
          <p className="mx-auto mt-3 max-w-2xl text-slate-300">From a sentence to a browser task, with the traffic captured along the way.</p>
        </div>
        <Flow steps={AI_FLOW} />
      </section>

      {/* tech */}
      <Section id="stack" eyebrow="Under the hood" title="Technology stack">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {STACK.map(s => (
            <Glass key={s.t} hover className="p-5 text-center">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-white/10"><s.icon size={22} className="text-sky-300" /></span>
              <div className="mt-3 font-semibold text-white">{s.t}</div><div className="mt-1 text-xs text-slate-400">{s.d}</div>
            </Glass>))}
        </div>
      </Section>

      {/* note */}
      <Glass className="mx-auto mt-20 max-w-3xl p-6 text-sm text-slate-300">
        <b className="text-white">Good to know:</b> HTTPS/TLS contents are encrypted and cannot be read. Protocol names are port-based labels. Live packet capture needs Npcap and an Administrator terminal on Windows, and it records the whole network adapter, so other apps’ traffic can appear too.
      </Glass>

      {/* CTA */}
      <Glass strong className="mx-auto mt-16 max-w-4xl p-10 text-center">
        <h2 className="text-2xl font-extrabold text-white sm:text-3xl">Ready to analyze some traffic?</h2>
        <p className="mt-2 text-slate-300">Pick a tool and jump straight in.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button onClick={() => go('/pcap')} className="btn-primary rounded-full px-7 py-3">PCAP Uploader</button>
          <button onClick={() => go('/automation')} className="btn-glass rounded-full px-7 py-3">AI Automation</button>
        </div>
      </Glass>
    </div>
  )
}
