import { useState, useRef, useMemo } from 'react'
import { BarChart, Bar, Cell, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie,
  LineChart, Line, Legend, CartesianGrid } from 'recharts'
import { Activity, Database, Network, ShieldAlert, UploadCloud, Loader2, RefreshCw } from 'lucide-react'
import { Glass, Panel, PageHeader } from './Glass.jsx'

export const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const PALETTE = ['#60a5fa', '#38bdf8', '#22d3ee', '#8b5cf6', '#bae6fd', '#a5b4fc', '#c4b5fd']
const fmtBytes = b => b >= 1e9 ? (b / 1e9).toFixed(2) + ' GB' : b >= 1e6 ? (b / 1e6).toFixed(2) + ' MB' : (b / 1e3).toFixed(1) + ' KB'
const fmtNum = n => n.toLocaleString()
const tip = { background: 'rgba(15,10,40,.85)', border: '1px solid rgba(255,255,255,.2)', borderRadius: 14, backdropFilter: 'blur(10px)' }

function Stat({ label, value, icon: Icon, note }) {
  return (
    <Glass hover className="p-6 text-white">
      <div className="text-sm text-slate-300">{label}</div>
      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="text-3xl font-semibold">{value}</span>
        <span className="grid h-10 w-10 place-items-center rounded-2xl bg-white/10"><Icon className="text-sky-300" size={20} /></span>
      </div>
      {note && <div className="mt-1 truncate text-xs text-slate-400">{note}</div>}
    </Glass>
  )
}

function Uploader({ onFile, busy, error }) {
  const ref = useRef()
  const [drag, setDrag] = useState(false)
  return (
    <Glass strong
      onDragOver={e => { e.preventDefault(); setDrag(true) }} onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files[0]) }}
      className={`mx-auto mt-6 flex max-w-2xl flex-col items-center border-dashed p-12 text-center text-white ${drag ? '!border-sky-300' : ''}`}>
      <span className="grid h-20 w-20 place-items-center rounded-3xl bg-white/10">
        {busy ? <Loader2 className="animate-spin text-sky-300" size={38} /> : <UploadCloud className="text-sky-300" size={38} />}
      </span>
      <h2 className="mt-5 text-2xl font-semibold">{busy ? 'Analyzing capture…' : 'Drop your capture here'}</h2>
      <p className="mt-2 max-w-md text-sm text-slate-300">Drag a .pcap or .pcapng file (up to 200 MB). Every number on the dashboard comes from the file you upload.</p>
      <button disabled={busy} onClick={() => ref.current.click()} className="btn-primary mt-6 rounded-full px-6 py-2.5">Choose file</button>
      <input ref={ref} type="file" accept=".pcap,.pcapng" hidden onChange={e => onFile(e.target.files[0])} />
      {error && <p className="mt-4 text-sm text-red-300">{error}</p>}
    </Glass>
  )
}

export default function PcapPage({ cap, setCap }) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [metric, setMetric] = useState('packets')
  const [range, setRange] = useState('all')

  async function upload(file) {
    if (!file) return
    setBusy(true); setError('')
    try {
      const fd = new FormData(); fd.append('file', file)
      const r = await fetch(`${API}/api/captures`, { method: 'POST', body: fd })
      const j = await r.json()
      if (!r.ok) throw new Error(j.detail || 'Upload failed')
      setCap(j)
    } catch (e) { setError(e.message === 'Failed to fetch' ? 'Cannot reach the backend. Is it running on port 8000?' : e.message) }
    setBusy(false)
  }

  const timeline = useMemo(() => {
    if (!cap) return []
    const end = cap.timeline.at(-1)?.t ?? 0
    const win = { all: Infinity, '60': 60, '300': 300 }[range]
    return cap.timeline.filter(p => p.t >= end - win)
  }, [cap, range])

  const total = cap?.total_packets || 1
  const maxHost = cap?.hosts?.[0]?.packets || 1

  return (
    <div>
      <PageHeader eyebrow="PCAP Uploader" title={cap ? 'Capture Dashboard' : 'Upload a packet capture'}
        subtitle={cap ? `Analysis of ${cap.name}` : 'Upload a .pcap / .pcapng file and get protocol, traffic, host and suspicious-pattern analysis.'} />
      {!cap ? <Uploader onFile={upload} busy={busy} error={error} /> : (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-4 fade-in">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:col-span-4 lg:grid-cols-4">
            <Stat label="Total Packets" value={fmtNum(cap.total_packets)} icon={Activity} note={cap.name} />
            <Stat label="Total Data Transferred" value={fmtBytes(cap.total_bytes)} icon={Database} />
            <Stat label="Active Protocols" value={cap.protocols.length} icon={Network} />
            <Stat label="Suspicious Patterns" value={cap.suspicious.length} icon={ShieldAlert} note="From built-in rules only" />
          </div>

          <Panel className="md:col-span-4 lg:col-span-2" title="Traffic by Protocol"
            right={<div className="flex rounded-full bg-black/25 p-1 text-xs text-slate-300">
              {['packets', 'bytes'].map(m => <button key={m} onClick={() => setMetric(m)}
                className={`rounded-full px-3 py-1 capitalize ${metric === m ? 'btn-primary' : ''}`}>{m}</button>)}</div>}>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={cap.protocols}>
                <XAxis dataKey="protocol" stroke="#94a3b8" tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} axisLine={false} tickFormatter={v => metric === 'bytes' ? fmtBytes(v) : v >= 1000 ? v / 1000 + 'K' : v} width={60} />
                <Tooltip cursor={false} contentStyle={tip} formatter={v => metric === 'bytes' ? fmtBytes(v) : fmtNum(v)} />
                <Bar dataKey={metric} radius={[10, 10, 10, 10]} maxBarSize={44}>
                  {cap.protocols.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Panel>

          <Panel className="md:col-span-4 lg:col-span-2" title="Protocol Distribution">
            <div className="flex flex-col items-center gap-4 sm:flex-row">
              <ResponsiveContainer width="100%" height={240}>
                <PieChart><Pie data={cap.protocols} dataKey="packets" nameKey="protocol" innerRadius="55%" outerRadius="95%" stroke="none" paddingAngle={2}>
                  {cap.protocols.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}</Pie>
                  <Tooltip contentStyle={tip} /></PieChart>
              </ResponsiveContainer>
              <ul className="w-full space-y-3 text-sm text-slate-200">
                {cap.protocols.map((p, i) => (
                  <li key={p.protocol} className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: PALETTE[i % PALETTE.length] }} />
                    <span className="flex-1">{p.protocol}</span>
                    <span className="text-slate-400">{fmtNum(p.packets)}</span>
                    <span className="w-14 text-right">{(p.packets / total * 100).toFixed(1)}%</span>
                  </li>))}
              </ul>
            </div>
          </Panel>

          <Panel className="md:col-span-4 lg:col-span-3" title="Network Traffic Over Time"
            right={<select value={range} onChange={e => setRange(e.target.value)} className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs text-slate-100 outline-none">
              <option value="all">Full capture</option><option value="300">Last 5 min</option><option value="60">Last 60 s</option></select>}>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={timeline}>
                <CartesianGrid stroke="#ffffff14" vertical={false} />
                <XAxis dataKey="t" stroke="#94a3b8" tickLine={false} axisLine={false} tickFormatter={v => v + 's'} />
                <YAxis yAxisId="l" stroke="#94a3b8" tickLine={false} axisLine={false} width={50} />
                <YAxis yAxisId="r" orientation="right" stroke="#94a3b8" tickLine={false} axisLine={false} tickFormatter={fmtBytes} width={70} />
                <Tooltip contentStyle={tip} formatter={(v, n) => n === 'Bytes/s' ? fmtBytes(v) : fmtNum(v)} labelFormatter={v => `t = ${v}s`} />
                <Legend />
                <Line yAxisId="l" name="Packets/s" dataKey="packets" stroke="#38bdf8" strokeWidth={2.5} dot={false} />
                <Line yAxisId="r" name="Bytes/s" dataKey="bytes" stroke="#22d3ee" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
            <p className="mt-2 text-xs text-slate-400">Incoming/outgoing is not shown: a raw capture does not reliably identify which side is local.</p>
          </Panel>

          <Panel className="md:col-span-4 lg:col-span-1" title="Traffic by Host">
            {cap.hosts.length === 0 ? <p className="text-sm text-slate-400">No public hosts observed.</p> :
              <ul className="space-y-4 text-sm text-slate-200">
                {cap.hosts.map(h => (
                  <li key={h.ip}>
                    <div className="flex justify-between gap-2"><span className="truncate" title={h.ip}>{h.host}</span><span className="text-slate-400">{fmtNum(h.packets)}</span></div>
                    <div className="mt-1 h-1.5 rounded bg-white/10"><div className="h-1.5 rounded bg-gradient-to-r from-sky-300 to-indigo-300" style={{ width: `${h.packets / maxHost * 100}%` }} /></div>
                    {!h.named_via_dns && <div className="mt-0.5 text-[10px] text-slate-500">unresolved IP</div>}
                  </li>))}
              </ul>}
          </Panel>

          {cap.suspicious.length > 0 && (
            <Panel className="md:col-span-4" title="Flagged Patterns">
              <ul className="space-y-2 text-sm text-slate-200">{cap.suspicious.map((s, i) => <li key={i}><b className="text-amber-300">{s.rule}:</b> {s.detail}</li>)}</ul>
            </Panel>)}
          {cap.truncated && <p className="text-xs text-slate-400 md:col-span-4">Totals cover the whole file; charts and tables use the first {fmtNum(cap.rows_kept)} packets.</p>}
          <div className="md:col-span-4">
            <button onClick={() => setCap(null)} className="btn-glass flex items-center gap-2 rounded-full px-5 py-2 text-sm"><RefreshCw size={15} />Load another file</button>
          </div>
        </div>
      )}
    </div>
  )
}
