import { useRef, useState } from 'react'
import { Play, Pause, Square, Loader2, CheckCircle2, XCircle, MinusCircle, LayoutDashboard } from 'lucide-react'
import { Panel, PageHeader } from './Glass.jsx'

const WS = (import.meta.env.VITE_API_URL || 'http://localhost:8000').replace('http', 'ws') + '/ws/automation'
const EXAMPLE = 'Open YouTube, search for Python tutorials, then open GitHub and search for Python networking projects.'
const kb = b => b >= 1e6 ? (b / 1e6).toFixed(2) + ' MB' : (b / 1e3).toFixed(1) + ' KB'

export default function Automation({ onCapture }) {
  const [prompt, setPrompt] = useState(EXAMPLE)
  const [steps, setSteps] = useState([])
  const [blocked, setBlocked] = useState([])
  const [state, setState] = useState('idle')
  const [shot, setShot] = useState(null)
  const [page, setPage] = useState(null)
  const [confirm, setConfirm] = useState(null)
  const [summary, setSummary] = useState('')
  const [error, setError] = useState('')
  const [capture, setCapture] = useState(true)
  const [capMsg, setCapMsg] = useState('')
  const [packets, setPackets] = useState([])
  const [pstats, setPstats] = useState(null)
  const [net, setNet] = useState([])
  const [ready, setReady] = useState(null)
  const [browserOnly, setBrowserOnly] = useState(false)
  const ws = useRef(null)
  const send = o => ws.current?.readyState === 1 && ws.current.send(JSON.stringify(o))
  const active = ['planning', 'running', 'paused'].includes(state)

  function run() {
    setSteps([]); setBlocked([]); setShot(null); setPage(null); setSummary(''); setError(''); setState('planning')
    setPackets([]); setPstats(null); setNet([]); setReady(null); setCapMsg('')
    ws.current?.close()
    const s = new WebSocket(WS); ws.current = s
    s.onopen = () => s.send(JSON.stringify({ type: 'run', prompt, capture }))
    s.onerror = () => { setError('Cannot reach the backend on port 8000.'); setState('idle') }
    s.onmessage = e => {
      const m = JSON.parse(e.data)
      if (m.type === 'plan') { setSteps(m.steps.map(t => ({ text: t, status: 'pending' }))); setBlocked(m.blocked); if (!m.steps.length) { setState('idle'); setError('No allowed steps could be planned from that request.') } }
      else if (m.type === 'step') setSteps(p => p.map((x, i) => i === m.index ? { ...x, status: m.status, detail: m.detail } : x))
      else if (m.type === 'shot') { setShot(m.data); setPage({ url: m.url, title: m.title }) }
      else if (m.type === 'status') setState(m.state)
      else if (m.type === 'confirm') setConfirm(m)
      else if (m.type === 'done') { setState(m.state); setSummary(m.summary); setConfirm(null) }
      else if (m.type === 'error') { setError(m.message); setState('idle') }
      else if (m.type === 'packets') { setPstats(m.stats); setPackets(p => [...m.rows.slice().reverse(), ...p].slice(0, 300)) }
      else if (m.type === 'net') setNet(p => [{ ...m }, ...p].slice(0, 300))
      else if (m.type === 'net_size') setNet(p => p.map(x => x.id === m.id ? { ...x, bytes: m.bytes } : x))
      else if (m.type === 'capture_status') setCapMsg(m.state === 'capturing' ? 'Capturing packets…' : m.message)
      else if (m.type === 'capture_ready') { setReady(m.capture); setCapMsg(`Capture saved on the server: ${m.path}`) }
    }
  }
  const answer = approve => { send({ type: 'confirm', approve }); setConfirm(null) }
  const icon = st => st === 'running' ? <Loader2 size={16} className="animate-spin text-sky-300" /> : st === 'done' ? <CheckCircle2 size={16} className="text-emerald-400" />
    : st === 'error' ? <XCircle size={16} className="text-red-400" /> : st === 'skipped' ? <MinusCircle size={16} className="text-slate-400" /> : <span className="h-3 w-3 rounded-full bg-white/20" />
  const shown = browserOnly ? packets.filter(p => p.browser) : packets
  const th = 'sticky top-0 bg-[#1a1240] px-2 py-1 text-left font-medium text-slate-300'

  return (
    <div>
    <PageHeader eyebrow="AI Automation" title="AI Automation Dashboard" subtitle="Describe a browser task in plain English. The AI plans safe steps, Chrome executes them, and your network traffic is captured live." />
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-5 fade-in">
      <Panel title="AI Website Automation" className="lg:col-span-5">
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={2} disabled={active}
          className="w-full rounded-2xl glass-inset p-3 text-sm text-white outline-none focus:border-sky-300/60" placeholder="Describe what the browser should do…" />
        <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
          <button onClick={run} disabled={active || !prompt.trim()} className="flex items-center gap-2 btn-primary rounded-full px-5 py-2"><Play size={16} />Run Task</button>
          {state === 'paused' ? <button onClick={() => send({ type: 'resume' })} className="flex items-center gap-2 btn-glass rounded-full px-4 py-2"><Play size={16} />Resume</button>
            : <button onClick={() => send({ type: 'pause' })} disabled={state !== 'running'} className="flex items-center gap-2 btn-glass rounded-full px-4 py-2"><Pause size={16} />Pause</button>}
          <button onClick={() => send({ type: 'stop' })} disabled={!active} className="flex items-center gap-2 btn-glass rounded-full px-4 py-2"><Square size={16} />Stop</button>
          <label className="flex items-center gap-2 text-slate-300"><input type="checkbox" checked={capture} disabled={active} onChange={e => setCapture(e.target.checked)} />Capture network packets while running</label>
          <span className="ml-auto text-slate-300">Status: <b className="capitalize text-sky-300">{state}</b></span>
        </div>
        <p className="mt-2 text-xs text-slate-400">Allowed sites: YouTube, GitHub, Google, Wikipedia, LinkedIn. A Chrome window opens on your PC. Packet capture needs Npcap and an Administrator terminal.</p>
        {error && <p className="mt-3 text-sm text-red-300">{error}</p>}
      </Panel>

      <Panel title="Execution Timeline" className="lg:col-span-2">
        {state === 'planning' && <p className="flex items-center gap-2 text-sm text-slate-300"><Loader2 size={16} className="animate-spin" />Planning steps…</p>}
        {!steps.length && state === 'idle' && <p className="text-sm text-slate-400">No task run yet.</p>}
        <ol className="space-y-3 text-sm text-slate-200">
          {steps.map((s, i) => <li key={i} className="flex gap-2">{icon(s.status)}<div><div>{s.text}</div>{s.detail && <div className="text-xs text-red-300">{s.detail}</div>}</div></li>)}
        </ol>
        {blocked.map((b, i) => <p key={i} className="mt-2 text-xs text-amber-300">{b}</p>)}
        {summary && <p className="mt-4 rounded-2xl glass-inset p-3 text-sm text-slate-200"><b className="capitalize text-sky-300">{state}:</b> {summary}</p>}
      </Panel>

      <Panel title="Browser Preview" className="lg:col-span-3">
        <div className="mb-2 truncate rounded-full glass-inset px-3 py-1 text-xs text-slate-300">{page ? `${page.title} · ${page.url}` : 'No page open'}</div>
        {shot ? <img alt="Latest browser screenshot" src={`data:image/jpeg;base64,${shot}`} className="w-full rounded-2xl" />
          : <div className="flex h-64 items-center justify-center rounded-2xl glass-inset text-sm text-slate-500">Screenshots appear here after each step</div>}
        <p className="mt-2 text-xs text-slate-500">Screenshot after each step, not live video.</p>
      </Panel>

      <Panel title="Live Packet Transfer" className="lg:col-span-5"
        right={<label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={browserOnly} onChange={e => setBrowserOnly(e.target.checked)} />Only IPs the automated browser contacted</label>}>
        {capMsg && <p className="mb-2 text-xs text-sky-300">{capMsg}</p>}
        {pstats && <div className="mb-3 flex flex-wrap gap-2 text-xs text-slate-200">
          <span className="rounded-full glass-inset px-3 py-1">Packets: <b>{pstats.total.toLocaleString()}</b></span>
          <span className="rounded-full glass-inset px-3 py-1">Data: <b>{kb(pstats.bytes)}</b></span>
          {Object.entries(pstats.protocols).map(([k, v]) => <span key={k} className="rounded-full glass-inset px-3 py-1">{k}: <b>{v}</b></span>)}
        </div>}
        {ready && <button onClick={() => onCapture(ready)} className="mb-3 flex items-center gap-2 btn-primary rounded-full px-4 py-2 text-sm"><LayoutDashboard size={16} />Open this capture in Dashboard</button>}
        <div className="max-h-80 overflow-auto rounded-2xl glass-inset p-2">
          <table className="w-full text-xs text-slate-200"><thead><tr><th className={th}>Time</th><th className={th}>Source</th><th className={th}>Destination</th><th className={th}>Proto</th><th className={th}>Len</th><th className={th}>Info</th></tr></thead>
            <tbody>{shown.map((p, i) => (
              <tr key={i} className={p.browser ? 'text-sky-200' : ''}>
                <td className="px-2 py-0.5">{p.t}s</td><td className="px-2">{p.src}{p.sport ? ':' + p.sport : ''}</td><td className="px-2">{p.dst}{p.dport ? ':' + p.dport : ''}</td>
                <td className="px-2">{p.proto}</td><td className="px-2">{p.len}</td><td className="max-w-[320px] truncate px-2 text-slate-400">{p.info}</td></tr>))}</tbody></table>
          {!shown.length && <p className="p-4 text-center text-xs text-slate-500">{capture ? 'Packets appear here while a task runs. Latest 300 shown; totals count everything and the full capture is saved.' : 'Packet capture is off.'}</p>}
        </div>
        <p className="mt-2 text-xs text-slate-500">Packets are captured on the whole network adapter, so other apps' traffic can appear. Highlighted rows involve IPs the automated browser actually connected to. HTTPS contents are encrypted and not readable.</p>
      </Panel>

      <Panel title="Browser Network Requests (from Chrome)" className="lg:col-span-5">
        <div className="max-h-72 overflow-auto rounded-2xl glass-inset p-2">
          <table className="w-full text-xs text-slate-200"><thead><tr><th className={th}>Status</th><th className={th}>Type</th><th className={th}>URL</th><th className={th}>Remote</th><th className={th}>Protocol</th><th className={th}>TLS</th><th className={th}>Size</th></tr></thead>
            <tbody>{net.map(r => (
              <tr key={r.id}><td className="px-2 py-0.5">{r.status}</td><td className="px-2">{r.rtype}</td><td className="max-w-[360px] truncate px-2" title={r.url}>{r.url}</td>
                <td className="px-2">{r.ip}{r.port ? ':' + r.port : ''}</td><td className="px-2">{r.proto}</td><td className="px-2">{r.tls}</td><td className="px-2">{r.bytes != null ? kb(r.bytes) : '…'}</td></tr>))}</tbody></table>
          {!net.length && <p className="p-4 text-center text-xs text-slate-500">Requests Chrome makes appear here (works without Npcap).</p>}
        </div>
      </Panel>

      {confirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="glass-strong max-w-sm rounded-3xl p-6 text-white">
            <h4 className="text-lg font-semibold">Confirm action</h4>
            <p className="mt-2 text-sm text-slate-300">The agent wants to: {confirm.text}</p>
            <div className="mt-5 flex gap-2"><button onClick={() => answer(true)} className="btn-primary rounded-full px-4 py-2">Allow</button>
              <button onClick={() => answer(false)} className="btn-glass rounded-full px-4 py-2">Skip</button></div>
          </div>
        </div>)}
    </div>
    </div>
  )
}
