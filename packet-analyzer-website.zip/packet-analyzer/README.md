# Network Packet Analyzer

## Run
Backend (Python 3.10+):

    cd backend && python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env   # put your Groq key in .env
    uvicorn main:app --reload --port 8000

Frontend (Node 18+):

    cd frontend && npm install && npm run dev   # http://localhost:5173

Never commit `.env`.

## Pages (hash routes, no extra dependency)
- `#/`           Home: what the site is, features, workflows, tech stack
- `#/pcap`       PCAP Uploader + capture dashboard
- `#/automation` AI Automation dashboard

UI: glassmorphism (frosted `backdrop-blur` panels over an animated gradient background, see `src/index.css`).
